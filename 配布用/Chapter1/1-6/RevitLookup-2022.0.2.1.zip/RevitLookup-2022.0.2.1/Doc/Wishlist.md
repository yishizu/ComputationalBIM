# Wishlist

- Jeremy Tammik would like to:
    - Integrate [GeoSnoop](http://thebuildingcoder.typepad.com/blog/2013/04/geosnoop-net-boundary-curve-loop-visualisation.html)
- Rudolf Honke suggests:
    - 3D-Control
    - Palette
    - Modeless, MDI, Docking &ndash; the former two are done in 2022.0.1.1

